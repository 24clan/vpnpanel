<p align="center">
<a href="https://github.com/24clan/Autoscript/blob/master/README.md" target="_blank"><img src="https://img.shields.io/badge/-🏠 Home-blue.svg"></a>
<a href="https://github.com/24clan/Autoscript/blob/master/demo.md" target="_blank"><img src="https://img.shields.io/badge/-💢 Demo-blue.svg"></a>
<a href="https://github.com/24clan/Autoscript/blob/master/download.md" target="_blank"><img src="https://img.shields.io/badge/-⏬ Download-blue.svg"></a>
<a href="https://www.youtube.com/playlist?list=PLzBcA76rWoRg98Ef6hva_6S-Txl35Wl5p" target="_blank"><img src="https://img.shields.io/badge/-📺 Tutorials-blue.svg"></a>
<a href="https://github.com/24clan/Autoscript/blob/master/contact.md" target="_blank"><img src="https://img.shields.io/badge/-📲 Contact-blue.svg"></a>
</p>
<p></p>
Download software for Android 
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.sonelli.juicessh" target="_blank"><img src="https://img.shields.io/badge/- Juicessh-yellow.svg"></a>
<a href="https://play.google.com/store/apps/details?id=net.openvpn.openvpn" target="_blank"><img src="https://img.shields.io/badge/- Openvpn-orange.svg"></a>
<a href="https://play.google.com/store/apps/details?id=com.evozi.injector" target="_blank"><img src="https://img.shields.io/badge/- Http Injector-lightgrey.svg"></a>
<a href="https://play.google.com/store/apps/details?id=org.zwanoo.android.speedtest" target="_blank"><img src="https://img.shields.io/badge/- Speedtest-red.svg"></a>
<a href="https://play.google.com/store/apps/details?id=com.aor.droidedit" target="_blank"><img src="https://img.shields.io/badge/- Code edit-green.svg"></a>
<a href="https://play.google.com/store/apps/details?id=org.connectbot" target="_blank"><img src="https://img.shields.io/badge/- Connectboot-grey.svg"></a>
<a href="https://play.google.com/store/apps/details?id=team.dev.epro.proxyserver" target="_blank"><img src="https://img.shields.io/badge/- Epoxy-red.svg"></a>
  </p>
Download software for PC
  <p align="center">
<a href="https://the.earth.li/~sgtatham/putty/latest/x86/putty.exe" target="_blank"><img src="https://img.shields.io/badge/-Putty 32bit-yellow.svg"></a>
<a href="http://www.treshaut.net/tels/windows/putty/x64/putty.exe" target="_blank"><img src="https://img.shields.io/badge/- Putty 64bit-blue.svg"></a>
<a href="https://bvdl.s3-eu-west-1.amazonaws.com/BvSshServer-Inst.exe" target="_blank"><img src="https://img.shields.io/badge/- BvSshServer-grey.svg"></a>
<a href="https://swupdate.openvpn.org/community/releases/openvpn-install-2.4.2-I601.exe" target="_blank"><img src="https://img.shields.io/badge/- Openvpn-orange.svg"></a>
  </p>

<p></p>
<p align="center"><a href="https://telegram.me/LeeDzung"><img src="https://img.shields.io/badge/Copyright%20©-Lee%20Dzung%20Autoscript%202019.%20All%20rights%20reserved...-green.svg"></a></p>
