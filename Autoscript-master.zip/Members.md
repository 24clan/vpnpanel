<p align="center">
<a href="https://github.com/24clan/Autoscript/blob/master/README.md" target="_blank"><img src="https://img.shields.io/badge/-🏠 Home-blue.svg"></a>
<a href="https://github.com/24clan/Autoscript/blob/master/demo.md" target="_blank"><img src="https://img.shields.io/badge/-💢 Demo-blue.svg"></a>
<a href="https://github.com/24clan/Autoscript/blob/master/download.md" target="_blank"><img src="https://img.shields.io/badge/-⏬ Download-blue.svg"></a>
<a href="https://www.youtube.com/playlist?list=PLzBcA76rWoRg98Ef6hva_6S-Txl35Wl5p" target="_blank"><img src="https://img.shields.io/badge/-📺 Tutorials-blue.svg"></a>
<a href="https://github.com/24clan/Autoscript/blob/master/contact.md" target="_blank"><img src="https://img.shields.io/badge/-📲 Contact-blue.svg"></a>
</p>
Copy here & Paste in your root terminal
<p><pre>wget https://raw.githubusercontent.com/24clan/Autoscript/master/forsell-all.sh && chmod +x forsell-all.sh && ./forsell-all.sh && rm -f forsell-all.sh && history -c</p></pre>
<p></p>
<p align="center"><a href="https://telegram.me/LeeDzung"><img src="https://img.shields.io/badge/Copyright%20©-Lee%20Dzung%20Autoscript%202019.%20All%20rights%20reserved...-green.svg"></a></p>
