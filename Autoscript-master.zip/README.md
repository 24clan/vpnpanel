<p align="center">
<a href="https://github.com/24clan/Autoscript/blob/master/README.md" target="_blank"><img src="https://img.shields.io/badge/-🏠 Home-blue.svg"></a>
<a href="https://github.com/24clan/Autoscript/blob/master/demo.md" target="_blank"><img src="https://img.shields.io/badge/-💢 Demo-blue.svg"></a>
<a href="https://github.com/24clan/Autoscript/blob/master/download.md" target="_blank"><img src="https://img.shields.io/badge/-⏬ Download-blue.svg"></a>
<a href="https://www.youtube.com/playlist?list=PLzBcA76rWoRg98Ef6hva_6S-Txl35Wl5p" target="_blank"><img src="https://img.shields.io/badge/-📺 Tutorials-blue.svg"></a>
<a href="https://github.com/24clan/Autoscript/blob/master/contact.md" target="_blank"><img src="https://img.shields.io/badge/-📲 Contact-blue.svg"></a>
</p>
<h1 align="center">Lee Dzung Autoscript</h1> 
<p align="center"><a href="https://telegram.me/LeeDzung" target="_blank"><img src="https://img.shields.io/badge/%2B60146463183-Whatsapp%2FTelegram-brightgreen.svg"></a> 
<p align="center"><a href="http://www.24clant.net" target="_blank"><img src="https://img.shields.io/badge/Website%20-Lee%20Dzung%20Autoscript-red.svg"></a>
</p>
<h2>Public Script
<a href="https://github.com/24clan/Autoscript/blob/master/Script.md" target="_blank"><img src="https://img.shields.io/badge/Life%20Time-IP%20Registered-lightgrey.svg"></a>
<a href="https://raw.githubusercontent.com/24clan/Autoscript/master/Pictures/main.jpg" target="_blank"><img src="https://img.shields.io/badge/Supported%20Linux%20x64-Debian%3A%207%2C%208%2C%209%20--%20Ubuntu%3A%2014%2C%2016%2C%2018%20%26%20above-yellowgreen.svg"></a>
</h2>
<pre>wget https://raw.githubusercontent.com/24clan/Autoscript/master/allinone.sh && chmod +x allinone.sh && ./allinone.sh && rm -f allinone.sh && history -c</pre>
  <p></p>
 <h2>Member Script
 <a href="https://github.com/24clan/Autoscript/blob/master/Members.md" target="_blank"> <img src="https://img.shields.io/badge/Life%20Time-Membership-orange.svg"> </a>
 <a href="https://raw.githubusercontent.com/24clan/Autoscript/master/Pictures/main.jpg" target="_blank"><img src="https://img.shields.io/badge/Supported%20Linux%20x64-Debian%3A%207%2C%208%2C%209%20--%20Ubuntu%3A%2014%2C%2016%2C%2018%20%26%20above-yellowgreen.svg"></a>
</h2>
<pre>wget https://raw.githubusercontent.com/24clan/Autoscript/master/forsell-all.sh && chmod +x forsell-all.sh && ./forsell-all.sh && rm -f forsell-all.sh && history -c</pre>
  <p></p>
<h3>Screenshots
  <a href="https://github.com/24clan/Autoscript/blob/master/demo.md" target="_blank"> <img src="https://img.shields.io/badge/Demo-OCS%20Panel%20V1%2C%202%2C%203%20%26%20Menu%20options-blue.svg"> </a>
</h3>
<div align="center">
  <img src="https://raw.githubusercontent.com/24clan/Autoscript/master/Pictures/main.jpg">
   </div>
    <p></p>
<p align="center"><a href="https://telegram.me/LeeDzung"><img src="https://img.shields.io/badge/Copyright%20©-Lee%20Dzung%20Autoscript%202019.%20All%20rights%20reserved...-green.svg"></a></p>
